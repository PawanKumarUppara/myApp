package com.farm.dao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.farm.model.Product;

public class ProductDao {
private List<Product> productList;

public List<Product> getProductList(){
	Product product1=new Product();
	product1.setProductId(1);
	product1.setProductName("guitar1");
	product1.setProductCategory("instrument");
	product1.setProductDescription("this is a federa guitar");
	product1.setProductPrice(200);
	product1.setProductCondition("new");
	product1.setProductStatus("Active");
	product1.setUnitInStock(112);
	product1.setProductManufacturer("feidera");
	
	Product product2=new Product();
	product2.setProductId(2);
	product2.setProductName("sitar1");
	product2.setProductCategory("dambola");
	product2.setProductDescription("this is a federa guitar");
	product2.setProductPrice(300);
	product2.setProductCondition("new-brand");
	product2.setProductStatus("Active-Super");
	product2.setUnitInStock(1);
	product2.setProductManufacturer("feidera-superah");
	
	
	Product product3=new Product();
	product3.setProductId(3);
	product3.setProductName("guitar1");
	product3.setProductCategory("instrument");
	product3.setProductDescription("this is a federa guitar");
	product3.setProductPrice(200);
	product3.setProductCondition("new");
	product3.setProductStatus("Active");
	product3.setUnitInStock(112);
	product3.setProductManufacturer("feidera");
	productList=new ArrayList<Product>();
	productList.add(product1);
	productList.add(product2);
	productList.add(product3);
	return productList;
	
}

public Product getProductById(int productid) throws IOException {
	// TODO Auto-generated method stub
	
	for(Product product:getProductList()){
		if(product.getProductId()==productid){
			return product;
		}
	}
	throw new IOException("no products found");
}
}
