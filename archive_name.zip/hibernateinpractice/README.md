# hibernateinpractice
this repo is been initiated as a quick refresher on jpa principles from basics to advanced
