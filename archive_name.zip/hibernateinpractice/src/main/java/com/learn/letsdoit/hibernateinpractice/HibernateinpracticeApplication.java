package com.learn.letsdoit.hibernateinpractice;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.learn.letsdoit.hibernateinpractice.entity.Course;
import com.learn.letsdoit.hibernateinpractice.repository.CourseRepository;
import com.learn.letsdoit.hibernateinpractice.repository.StudentRepository;
import com.learn.letsdoit.hibernateinpractice.repository.StudentRepositoryTest;

@SpringBootApplication
public class HibernateinpracticeApplication implements CommandLineRunner {

	
	
	
	private static final Logger log = LoggerFactory.getLogger(HibernateinpracticeApplication.class);

	@Autowired
	private CourseRepository courseRepository;
	@Autowired
	private StudentRepository studentRepository;

	public static void main(String[] args) {
		SpringApplication.run(HibernateinpracticeApplication.class, args);
	}

	
	
	@Override
	public void run(String... args) throws Exception {
		/*// TODO Auto-generated method stub
		log.info("find the course by ->{}",courseRepository.findById(10001L));
	//courseRepository.deleteById(10001L);
	Course course = courseRepository.save(new Course("Microservices in 60 steps"));
	
		log.info("inserting a course{}",course);*/
		
	//courseRepository.playWithEntityManager();
		
		log.info("stunet mike with passport{}",studentRepository.saveStudentWithPassport());
	}

	
}