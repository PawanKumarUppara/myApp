package com.learn.letsdoit.hibernateinpractice.repository;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import com.learn.letsdoit.hibernateinpractice.HibernateinpracticeApplication;
import com.learn.letsdoit.hibernateinpractice.entity.Course;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=HibernateinpracticeApplication.class)
public class CourseRepositoryTest {

	@Autowired
	private CourseRepository repository;

	private static final Logger log = LoggerFactory.getLogger(CourseRepositoryTest.class);

	@Test
	public void contextLoads() {
		log.info("test is running");

		Course findById = repository.findById(10001L);

		assertEquals("JPA in 50 Steps", findById.getName());





	}
	@Test
	@DirtiesContext
	public void deleteByIdBasic(){

		repository.deleteById(10002L);
		Course course = repository.findById(10002L);
		assertNull(course);
	}

	@Test
	@DirtiesContext
	public void save_basic(){
		Course course = repository.findById(10001L);

		assertEquals("JPA in 50 Steps", course.getName());
		course.setName("Jpa in 50 steps-updated");

		repository.save(course);
		Course course1 = repository.findById(10001L);
		assertEquals("Jpa in 50 steps-updated", course1.getName());



	}
	
	@Test
	@DirtiesContext
	public void playWithENtityManger(){
		repository.playWithEntityManager();
	}

	



}
