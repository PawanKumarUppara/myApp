package com.learn.letsdoit.hibernateinpractice.repository;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.learn.letsdoit.hibernateinpractice.HibernateinpracticeApplication;
import com.learn.letsdoit.hibernateinpractice.entity.Passport;
import com.learn.letsdoit.hibernateinpractice.entity.Student;

@RunWith(SpringRunner.class)
@SpringBootTest(classes=HibernateinpracticeApplication.class)
public class StudentRepositoryTest {

	@Autowired
	private StudentRepository repository;

	@Autowired
	EntityManager em;
	private static final Logger log = LoggerFactory.getLogger(StudentRepositoryTest.class);

	@Test
	@Transactional
	public void retreieveStudentAndPassportDetails() {
		log.info("test is running");
		
		Student student = em.find(Student.class, 20001L);
		
		
		log.info("student name{}",student.getName());
		log.info("Passport number eager fetch{}",student.getPassport());
		



	}
	
	

	@Test
	@Transactional
	public void retreievePassportAndStudentDetails() {
		log.info("test is running");
		
		Passport passport = em.find(Passport.class, 40001L);
		
		
		log.info("passport name{}",passport.getNumber());
		log.info("Passport number eager fetch{}",passport.getStudent().getName());
		



	}
	@Test
	public void someTest(){
		repository.someOperationToUnderstanPeristanceContext();
		
	}
	


}
